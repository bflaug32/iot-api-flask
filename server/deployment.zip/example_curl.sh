# how to post articles for dynamic web content
curl -H "Content-Type: application/json" -X POST -d '{"Python":"http://python.org"}' http://localhost:5000/api/v1/articles?key=sekret

