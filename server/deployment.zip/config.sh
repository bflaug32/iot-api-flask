# This API key allows your hardware to communicate with the server with a preconfigured passphrase
# It also can prevent other people from setting your alarm :)
#export MY_API_KEY='sekret'

# get your open weather api key here http://openweathermap.org/api
#export OPEN_WEATHER_API_KEY='mysekretzz'

export MY_API_KEY='sebastianbrads'
export OPEN_WEATHER_API_KEY='2770e40ee4f984d6688ec6162f1ded80'
