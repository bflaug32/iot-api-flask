from service import app
application = app
application.run(host='0.0.0.0')
