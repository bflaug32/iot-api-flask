class BaseConfig(object):
    DEBUG = False